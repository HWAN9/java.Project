package controller;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DB_Connection {
	private Connection con;
	private Statement st;
	private ResultSet rs;
	private PreparedStatement pstmt;

	public DB_Connection() {
		try {
			String user = "system";
			String pw = "1234";
			String url = "jdbc:oracle:thin:@localhost:1521:XE";

			Class.forName("oracle.jdbc.driver.OracleDriver");
			con = DriverManager.getConnection(url, user, pw);
			st = con.createStatement();

		} catch (Exception e) {
			System.out.println("�����ͺ��̽� ���� ����:" + e.getMessage());
		}
	}

	public void Search() {
		String SQL = "SELECT * FROM usedCar";
		try {
			rs = st.executeQuery(SQL);
			
			while (rs.next()) {
				String car_number=rs.getString("Car_Number");
				String car_type=rs.getString("Car_Type");
				String car_name=rs.getString("Car_Name");
				String made_company=rs.getString("Made_Company");
				int price=rs.getInt("Price");
				String made_year=rs.getString("Made_Year");
				int dis_driven=rs.getInt("Dis_Driven");
				String fuel_type=rs.getString("Fuel_Type");
				String color=rs.getString("Color");
				
				System.out.println("======================================");
				System.out.printf("%s \n", car_number);
				System.out.printf("%s \n", car_type);
				System.out.printf("%s \n", car_name);
				System.out.printf("%s \n", made_company);
				System.out.printf("%d����\n", price);
				System.out.printf("%s \n", made_year);
				System.out.printf("%d \n", dis_driven);
				System.out.printf("%s \n", fuel_type);
				System.out.printf("%s \n", color);
				System.out.println("======================================");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void InsertusedCar(String car_number, String car_type, String car_name, String made_company, int price, String made_year,
			int dis_driven, String fuel_type, String color) 
	{
		String SQL = "Insert INTO usedCar(Car_Number,Car_Type,Car_Name,Made_Company,Price,Made_Year,Dis_Driven,Fuel_Type,Color)"
				+ "VALUES (?,?,?,?,?,?,?,?,?)";

		try {
			pstmt = con.prepareStatement(SQL);
			pstmt.setString(1, car_number);
			pstmt.setString(2, car_type);
			pstmt.setString(3, car_name);
			pstmt.setString(4, made_company);
			pstmt.setInt(5, price);
			pstmt.setString(6, made_year);
			pstmt.setInt(7, dis_driven);
			pstmt.setString(8, fuel_type);
			pstmt.setString(9, color);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void SearchByNo(String input_car_number){
		String SQL="SELECT * FROM usedCar WHERE Car_Number="+"'"+input_car_number+"'";
		try{
			rs=st.executeQuery(SQL);
			
			while(rs.next()){
				
				String car_number=rs.getString("Car_Number");
				String car_type=rs.getString("Car_Type");
				String car_name=rs.getString("Car_Name");
				String made_company=rs.getString("Made_Company");
				int price=rs.getInt("Price");
				String made_year=rs.getString("Made_Year");
				int dis_driven=rs.getInt("Dis_Driven");
				String fuel_type=rs.getString("Fuel_Type");
				String color=rs.getString("Color");
				
				System.out.println("======================================");
				System.out.printf("%s \n", car_number);
				System.out.printf("%s \n", car_type);
				System.out.printf("%s \n", car_name);
				System.out.printf("%s \n", made_company);
				System.out.printf("%d����\n", price);
				System.out.printf("%s \n", made_year);
				System.out.printf("%d \n", dis_driven);
				System.out.printf("%s \n", fuel_type);
				System.out.printf("%s \n", color);
				System.out.println("======================================");
				
			}
		}catch(SQLException e){
			e.printStackTrace();
		}
	}
	
	public void DeleteusedCar(String car_number) {
		String SQL = "delete from usedCar where Car_Number=?";

		try {
			pstmt = con.prepareStatement(SQL);
			pstmt.setString(1, car_number);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
