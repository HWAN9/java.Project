package Java_DB;

import java.util.Scanner;

public class Java_main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Java_Connection db = new Java_Connection();

		int choice = 0;
		int no = 0;
		String name = "";
		int age = 0;
		double height = 0;
		int choice2 = 0;

		Scanner sc = new Scanner(System.in);

		while (true) {
			MenuClass.menu();
			choice = sc.nextInt();

			while (true) {
				if (choice == 1) {
					db.Search();
					break;
				}
				if (choice == 2) {
					System.out.println("1.��ȣ �˻�");
					System.out.println("2.�̸� �˻�");
					System.out.println("3.���� �˻�");
					System.out.println("4.��������");
					choice2=sc.nextInt();
					
					while(true) {
						if (choice2==1) {
							System.out.print("��ȣ �Է�:");
							no = sc.nextInt();
							db.SearchByNo(no);
							break;
						}
						if (choice2==2) {
							System.out.print("�̸� �Է�:");
							name = sc.next();
							db.SearchByName(name);
							break;
						}
						if (choice2==3) {
							System.out.print("���� �Է�:");
							age = sc.nextInt();
							db.SearchByAge(age);
							break;
						}
						if (choice2==4) {
							MenuClass.menu();
							choice=sc.nextInt();
							break;
						}
					}
				}
				if (choice == 3) {
					// ������ ����(�߰�)
					System.out.print("��ȣ �Է�:");
					no = sc.nextInt();
					System.out.print("�̸� �Է�:");
					name = sc.next();
					System.out.print("���� �Է�:");
					age = sc.nextInt();
					System.out.print("Ű �Է�:");
					height = sc.nextDouble();
					db.InsertPerson(no, name, age, height);
					break;
				}
				if (choice == 4) {
					System.out.print("�̸� �Է�:");
					name = sc.next();
					System.out.print("���� �Է�:");
					age = sc.nextInt();
					db.UpdatePerson(name, age);
					break;
				}
				if (choice == 5) {
					System.out.print("�̸� �Է�:");
					name = sc.next();
					db.DeletePerson(name);
					break;
				}
				if (choice == 0) {
					System.out.print("����");
					System.exit(0);
				}
			}
		}
	}
}
