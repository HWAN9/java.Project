package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import dto.usedCarVo;
import dto.wishBuyListVo;

public class usedCarDao {
	private ArrayList<usedCarVo> dtos;
	private Connection con;
	private Statement st;
	private PreparedStatement pstmt;
	private ResultSet rs;

	public usedCarDao() {
		dtos = new ArrayList<usedCarVo>();
		try {
			String user = "system";
			String pw = "1234";
			String url = "jdbc:oracle:thin:@localhost:1521:XE";
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con = DriverManager.getConnection(url, user, pw);
			st = con.createStatement();
		} catch (Exception e) {
			System.out.println("�����ͺ��̽� ���� ����:" + e.getMessage());
		}
	}

	public ArrayList<usedCarVo> getAllUsedCar() {
		String SQL = "SELECT * FROM usedcar";
		try {
			rs = st.executeQuery(SQL);
			while (rs.next()) {
				String car_number = rs.getString("car_number");
				String car_type = rs.getString("car_type");
				String car_name = rs.getString("car_name");
				String made_company = rs.getString("made_company");
				int price = rs.getInt("price");
				double made_year = rs.getDouble("made_year");
				int dis_driven = rs.getInt("dis_driven");
				String fuel_type = rs.getString("fuel_type");
				String color = rs.getString("color");
				usedCarVo VO = new usedCarVo(car_number, car_type, car_name, made_company, price, made_year, dis_driven,
						fuel_type, color);
				dtos.add(VO);
				// ArrayList�� ȸ������ �߰�

				System.out.printf("������ȣ : %s / ", car_number);
				System.out.printf("�������� : %s / ", car_type);
				System.out.printf("�𵨸� : %s / ", car_name);
				System.out.printf("������ : %s / ", made_company);
				System.out.printf("���� : %d���� / ", price);
				System.out.printf("���� : %.0f���� / ", made_year);
				System.out.printf("����Ÿ� : %dkm / ", dis_driven);
				System.out.printf("���� : %s / ", fuel_type);
				System.out.printf("���� : %s \n", color);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return dtos;
	}
	
	public void InsertusedCar(String car_number, String car_type, String car_name, String made_company, int price, double made_year,
			int dis_driven, String fuel_type, String color) 
	{
		String SQL = "Insert INTO usedCar(Car_Number,Car_Type,Car_Name,Made_Company,Price,Made_Year,Dis_Driven,Fuel_Type,Color)"
				+ "VALUES (?,?,?,?,?,?,?,?,?)";

		try {
			pstmt = con.prepareStatement(SQL);
			pstmt.setString(1, car_number);
			pstmt.setString(2, car_type);
			pstmt.setString(3, car_name);
			pstmt.setString(4, made_company);
			pstmt.setInt(5, price);
			pstmt.setDouble(6, made_year);
			pstmt.setInt(7, dis_driven);
			pstmt.setString(8, fuel_type);
			pstmt.setString(9, color);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void SearchByNo(String input_car_number) {
		String SQL = "SELECT * FROM usedCar WHERE Car_Number=" + "'" + input_car_number + "'";
		try {
			rs = st.executeQuery(SQL);

			while (rs.next()) {

				String car_number = rs.getString("Car_Number");
				String car_type = rs.getString("Car_Type");
				String car_name = rs.getString("Car_Name");
				String made_company = rs.getString("Made_Company");
				int price = rs.getInt("Price");
				double made_year = rs.getDouble("Made_Year");
				int dis_driven = rs.getInt("Dis_Driven");
				String fuel_type = rs.getString("Fuel_Type");
				String color = rs.getString("Color");

				System.out.printf("������ȣ : %s / ", car_number);
				System.out.printf("�������� : %s / ", car_type);
				System.out.printf("�𵨸� : %s / ", car_name);
				System.out.printf("������ : %s / ", made_company);
				System.out.printf("���� : %d���� / ", price);
				System.out.printf("���� : %.0f���� / ", made_year);
				System.out.printf("����Ÿ� : %dkm / ", dis_driven);
				System.out.printf("���� : %s / ", fuel_type);
				System.out.printf("���� : %s \n", color);

			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void UpdateusedCarbyCartype(String car_number, String car_type) {
		String SQL = "update usedCar set Car_Type=? where Car_Number=?";

		try {
			pstmt = con.prepareStatement(SQL);
			pstmt.setString(1, car_type);
			pstmt.setString(2, car_number);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void UpdateusedCarbyCarname(String car_number, String car_name) {
		String SQL = "update usedCar set Car_Name=? where Car_Number=?";

		try {
			pstmt = con.prepareStatement(SQL);
			pstmt.setString(1, car_name);
			pstmt.setString(2, car_number);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void UpdateusedCarbyCompany(String car_number, String made_company) {
		String SQL = "update usedCar set Made_Company=? where Car_Number=?";

		try {
			pstmt = con.prepareStatement(SQL);
			pstmt.setString(1, made_company);
			pstmt.setString(2, car_number);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void UpdateusedCarbyPrice(String car_number, int price) {
		String SQL = "update usedCar set Price=? where Car_Number=?";

		try {
			pstmt = con.prepareStatement(SQL);
			pstmt.setInt(1, price);
			pstmt.setString(2, car_number);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void UpdateusedCarbyYear(String car_number, double made_year) {
		String SQL = "update usedCar set Made_Year=? where Car_Number=?";

		try {
			pstmt = con.prepareStatement(SQL);
			pstmt.setDouble(1, made_year);
			pstmt.setString(2, car_number);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void UpdateusedCarbyDis(String car_number, int dis_driven) {
		String SQL = "update usedCar set Dis_Driven=? where Car_Number=?";

		try {
			pstmt = con.prepareStatement(SQL);
			pstmt.setInt(1, dis_driven);
			pstmt.setString(2, car_number);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void UpdateusedCarbyFuel(String car_number, String fuel_type) {
		String SQL = "update usedCar set Fuel_Type=? where Car_Number=?";

		try {
			pstmt = con.prepareStatement(SQL);
			pstmt.setString(1, fuel_type);
			pstmt.setString(2, car_number);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void UpdateusedCarbyColor(String car_number, String color) {
		String SQL = "update usedCar set Color=? where Car_Number=?";

		try {
			pstmt = con.prepareStatement(SQL);
			pstmt.setString(1, color);
			pstmt.setString(2, car_number);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void DeleteusedCar(String car_number) {
		String SQL = "delete from usedCar where Car_Number=?";

		try {
			pstmt = con.prepareStatement(SQL);
			pstmt.setString(1, car_number);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}