package controller;

import java.util.Scanner;
import service.usedCarService;

public class mainClass {
	
	public static void menuWhlie() {
		usedCarService ucs = new usedCarService();
		DB_Connection db = new DB_Connection();
		managementClass mClass = new managementClass();
		int choice = 0;
		boolean login = false;
		
		Scanner sc = new Scanner(System.in);
		while (true) {
			menuClass.menu();
			choice = sc.nextInt();
			if (choice == 1) {
				userClass.userMenu();
				choice = sc.nextInt();
				if (choice == 1) {
					menuClass.searchType();
				} else if (choice == 2) {
					
				} else if (choice == 3) {
					mainClass.menuWhlie();
				}
			} else if (choice == 2) {
			} else if (choice == 3) {
				if(login==false) {
					login=ucs.login(login);
					mClass.Menu();
				}else if(login==true){
					System.out.println("�α��� �Ϸ�");
					mClass.Menu();
				}
			} else if (choice == 4) {
				break;
			}
		}
	}
	
	public static void main(String[] args) {
		mainClass.menuWhlie();
	}
}